class User{
  final String username;
  final String Password;
  User({required this.username,required this.Password});



}