package com.example.alhadi_card;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
